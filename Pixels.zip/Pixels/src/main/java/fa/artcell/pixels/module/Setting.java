package fa.artcell.pixels.module;

public abstract class Setting {
    public final String name;
    protected Setting(String name) { this.name = name; }
    public abstract String display();
    /** button: 0 = left click, 1 = right click */
    public abstract void click(int button);

    public static class BoolSetting extends Setting {
        private boolean value;
        public BoolSetting(String name, boolean def) { super(name); value = def; }
        public boolean get() { return value; }
        @Override public String display() { return value ? "ON" : "OFF"; }
        @Override public void click(int button) { value = !value; }
    }

    public static class NumberSetting extends Setting {
        private double value;
        private final double min, max, step;
        public NumberSetting(String name, double def, double min, double max, double step) {
            super(name); this.value = def; this.min = min; this.max = max; this.step = step;
        }
        public double get() { return value; }
        public int getInt() { return (int) Math.round(value); }
        @Override public String display() { return step >= 1 ? String.valueOf(getInt()) : String.format("%.2f", value); }
        @Override public void click(int button) {
            value += button == 0 ? step : -step;
            value = Math.max(min, Math.min(max, value));
        }
    }

    public static class ModeSetting extends Setting {
        private final String[] modes;
        private int index;
        public ModeSetting(String name, String def, String... modes) {
            super(name); this.modes = modes;
            for (int i = 0; i < modes.length; i++) if (modes[i].equals(def)) index = i;
        }
        public String get() { return modes[index]; }
        @Override public String display() { return modes[index]; }
        @Override public void click(int button) {
            index = (index + (button == 0 ? 1 : modes.length - 1)) % modes.length;
        }
    }
}
