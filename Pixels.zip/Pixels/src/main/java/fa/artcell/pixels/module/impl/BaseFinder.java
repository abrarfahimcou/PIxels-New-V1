package fa.artcell.pixels.module.impl;

import fa.artcell.pixels.module.Module;
import fa.artcell.pixels.module.Setting.NumberSetting;
import net.minecraft.block.entity.BarrelBlockEntity;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.ChestBlockEntity;
import net.minecraft.block.entity.ShulkerBoxBlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.world.chunk.WorldChunk;
import java.util.HashSet;
import java.util.Set;

/** Scans already-loaded chunks for clusters of storage blocks. Client-side only, sends no packets. */
public class BaseFinder extends Module {
    private final NumberSetting radius = add(new NumberSetting("Chunk radius", 6, 1, 16, 1));
    private final NumberSetting minStorage = add(new NumberSetting("Min storage", 15, 3, 100, 1));
    private final Set<Long> reported = new HashSet<>();
    private int timer;

    public BaseFinder() { super("Storage Scan", Category.BASE_FINDER); }

    @Override protected void onEnable() { reported.clear(); timer = 0; }

    @Override
    public void onTick(MinecraftClient mc) {
        if (mc.player == null || mc.world == null || ++timer < 40) return;
        timer = 0;
        ChunkPos c = mc.player.getChunkPos();
        int r = radius.getInt();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                int cx = c.x + dx, cz = c.z + dz;
                long key = ChunkPos.toLong(cx, cz);
                if (reported.contains(key)) continue;
                WorldChunk chunk = mc.world.getChunkManager().getWorldChunk(cx, cz);
                if (chunk == null) continue;
                int count = 0;
                for (BlockEntity be : chunk.getBlockEntities().values()) {
                    if (be instanceof ChestBlockEntity || be instanceof BarrelBlockEntity || be instanceof ShulkerBoxBlockEntity) count++;
                }
                if (count >= minStorage.getInt()) {
                    reported.add(key);
                    mc.player.sendMessage(Text.literal("[Pixels] " + count + " storage blocks near " + (cx * 16) + ", " + (cz * 16)), false);
                }
            }
        }
    }
}
