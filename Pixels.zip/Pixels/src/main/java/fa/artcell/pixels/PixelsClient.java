package fa.artcell.pixels;

import fa.artcell.pixels.gui.ClickGuiScreen;
import fa.artcell.pixels.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import org.lwjgl.glfw.GLFW;

public class PixelsClient implements ClientModInitializer {
    private boolean wasDown;

    @Override
    public void onInitializeClient() {
        ModuleManager.init();
        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.getWindow() == null) return;
            // Right Shift opens the ClickGUI (polled directly, no KeyBinding API needed)
            boolean down = GLFW.glfwGetKey(mc.getWindow().getHandle(), GLFW.GLFW_KEY_RIGHT_SHIFT) == GLFW.GLFW_PRESS;
            if (down && !wasDown && mc.currentScreen == null && mc.player != null) {
                mc.setScreen(new ClickGuiScreen());
            }
            wasDown = down;
            if (mc.player != null && mc.world != null) ModuleManager.tick(mc);
        });
    }
}
