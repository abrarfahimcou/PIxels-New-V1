package fa.artcell.pixels.gui;

import fa.artcell.pixels.Theme;
import fa.artcell.pixels.module.Module;
import fa.artcell.pixels.module.Module.Category;
import fa.artcell.pixels.module.ModuleManager;
import fa.artcell.pixels.module.Setting;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import java.util.ArrayList;
import java.util.List;
import java.util.function.IntConsumer;

public class ClickGuiScreen extends Screen {
    private static final Category[] CATS = Category.values();
    private static int tab = 0;
    private static Module expanded;

    private static final int ROW_H = 16, TAB_H = 18, TOP = 28;

    private record Row(String label, String value, boolean on, IntConsumer click, boolean sub) {}

    public ClickGuiScreen() { super(Text.literal("Pixels")); }

    @Override public boolean shouldPause() { return false; }

    private int panelW() { return Math.min(405, width - 20); }
    private int panelX() { return (width - panelW()) / 2; }

    private List<Row> rows() {
        List<Row> r = new ArrayList<>();
        if (tab == CATS.length) { // Theme tab (includes the Font section)
            for (Setting s : Theme.SETTINGS) r.add(new Row(s.name, s.display(), false, s::click, false));
            return r;
        }
        for (Module m : ModuleManager.in(CATS[tab])) {
            r.add(new Row(m.name, m.isEnabled() ? "ON" : "OFF", m.isEnabled(), b -> {
                if (b == 0) m.toggle(); else if (b == 1) expanded = (expanded == m) ? null : m;
            }, false));
            if (expanded == m) for (Setting s : m.settings) r.add(new Row(s.name, s.display(), false, s::click, true));
        }
        return r;
    }

    private String tabLabel(int i) { return i == CATS.length ? "Theme" : CATS[i].label; }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        int acc = Theme.accent();
        boolean sh = Theme.SHADOW.get();
        ctx.fill(0, 0, width, height, 0x90000000);

        int x = panelX(), w = panelW();
        ctx.drawText(textRenderer, Theme.text("Pixels"), x, 10, acc, sh);
        Text tag = Theme.text("by- FA. Artcell");
        ctx.drawText(textRenderer, tag, x + w - textRenderer.getWidth(tag), 10, 0xFF8899A0, sh);

        int n = CATS.length + 1, tw = w / n;
        for (int i = 0; i < n; i++) {
            int tx = x + i * tw;
            boolean sel = i == tab;
            ctx.fill(tx, TOP, tx + tw - 1, TOP + TAB_H, sel ? 0xFF0B2A30 : 0xFF121A1C);
            if (sel) ctx.fill(tx, TOP + TAB_H - 2, tx + tw - 1, TOP + TAB_H, acc);
            Text t = Theme.text(tabLabel(i));
            ctx.drawText(textRenderer, t, tx + (tw - 1 - textRenderer.getWidth(t)) / 2, TOP + 5, sel ? acc : 0xFFB0BEC5, sh);
        }

        int y = TOP + TAB_H + 4;
        for (Row r : rows()) {
            int rx = x + (r.sub ? 10 : 0);
            boolean hover = mx >= rx && mx < x + w && my >= y && my < y + ROW_H - 1;
            int bg = r.on ? 0xFF0E3A42 : (hover ? 0xFF1C2A2D : 0xFF121A1C);
            ctx.fill(rx, y, x + w, y + ROW_H - 1, bg);
            if (r.on) ctx.fill(rx, y, rx + 2, y + ROW_H - 1, acc);
            ctx.drawText(textRenderer, Theme.text(r.label), rx + 6, y + 4, r.on ? acc : 0xFFE0F7FA, sh);
            Text v = Theme.text(r.value);
            ctx.drawText(textRenderer, v, x + w - 6 - textRenderer.getWidth(v), y + 4, r.on ? acc : 0xFF90A4AE, sh);
            y += ROW_H;
        }
        ctx.drawText(textRenderer, Text.literal("Left click: toggle / next    Right click: settings / previous    Esc: close"),
                x, height - 14, 0xFF607D8B, false);
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int button = click.button();
        int x = panelX(), w = panelW();

        if (my >= TOP && my < TOP + TAB_H && mx >= x && mx < x + w) {
            int n = CATS.length + 1, tw = w / n;
            tab = Math.min(n - 1, (int) ((mx - x) / tw));
            return true;
        }
        int y = TOP + TAB_H + 4;
        for (Row r : rows()) {
            int rx = x + (r.sub ? 10 : 0);
            if (mx >= rx && mx < x + w && my >= y && my < y + ROW_H - 1) {
                r.click.accept(button);
                return true;
            }
            y += ROW_H;
        }
        return super.mouseClicked(click, doubled);
    }
}
