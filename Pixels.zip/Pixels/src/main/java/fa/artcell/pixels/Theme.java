package fa.artcell.pixels;

import fa.artcell.pixels.module.Setting;
import fa.artcell.pixels.module.Setting.BoolSetting;
import fa.artcell.pixels.module.Setting.ModeSetting;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import java.util.List;

public final class Theme {
    private Theme() {}

    // Theme section
    public static final ModeSetting ACCENT = new ModeSetting("Accent", "Cyan", "Cyan", "Aqua", "Ice");
    // Font section
    public static final BoolSetting SHADOW = new BoolSetting("Font: shadow", true);
    public static final BoolSetting BOLD = new BoolSetting("Font: bold", false);
    public static final BoolSetting UPPER = new BoolSetting("Font: uppercase", false);

    public static final List<Setting> SETTINGS = List.of(ACCENT, SHADOW, BOLD, UPPER);

    public static int accent() {
        return switch (ACCENT.get()) {
            case "Aqua" -> 0xFF00FFC8;
            case "Ice" -> 0xFF9BF0FF;
            default -> 0xFF00E5FF;
        };
    }

    public static Text text(String s) {
        MutableText t = Text.literal(UPPER.get() ? s.toUpperCase() : s);
        return BOLD.get() ? t.formatted(Formatting.BOLD) : t;
    }
}
