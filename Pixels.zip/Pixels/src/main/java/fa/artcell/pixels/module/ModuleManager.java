package fa.artcell.pixels.module;

import fa.artcell.pixels.module.impl.BaseFinder;
import fa.artcell.pixels.module.impl.Fullbright;
import fa.artcell.pixels.module.impl.Sprint;
import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public final class ModuleManager {
    private static final List<Module> MODULES = new ArrayList<>();
    private ModuleManager() {}

    public static void init() {
        MODULES.add(new Sprint());
        MODULES.add(new Fullbright());
        MODULES.add(new BaseFinder());
        // Add new modules here.
    }

    public static List<Module> in(Module.Category c) {
        return MODULES.stream().filter(m -> m.category == c).toList();
    }

    public static void tick(MinecraftClient mc) {
        for (Module m : MODULES) if (m.isEnabled()) m.onTick(mc);
    }
}
