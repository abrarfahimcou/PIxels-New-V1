package fa.artcell.pixels.module;

import net.minecraft.client.MinecraftClient;
import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    public enum Category {
        LEGIT("Legit"), COMBAT("Combat"), PLAYER("Player"), RENDER("Render"),
        MISC("Misc"), DONUT("Donut"), BASE_FINDER("Base"), UTILITY("Utility");
        public final String label;
        Category(String label) { this.label = label; }
    }

    public final String name;
    public final Category category;
    public final List<Setting> settings = new ArrayList<>();
    private boolean enabled;

    protected Module(String name, Category category) { this.name = name; this.category = category; }

    protected <T extends Setting> T add(T setting) { settings.add(setting); return setting; }

    public boolean isEnabled() { return enabled; }
    public void toggle() { setEnabled(!enabled); }
    public void setEnabled(boolean e) {
        if (e == enabled) return;
        enabled = e;
        if (e) onEnable(); else onDisable();
    }

    protected void onEnable() {}
    protected void onDisable() {}
    public void onTick(MinecraftClient mc) {}
}
